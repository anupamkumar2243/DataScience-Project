import cv2
import face_recognition
import pickle
import os
import mysql.connector

# Set up your MySQL connection
db_connection = mysql.connector.connect(
    host="localhost",
    user="Roney",
    password="root",
    database="face_recognition"
)
def create_table():
    cursor = db_connection.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS Students (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), image BLOB, encoding BLOB)")
    db_connection.commit()
    cursor.close()

def insert_student_data(name, image, encoding):
    cursor = db_connection.cursor()
    cursor.execute("INSERT INTO Students (name, image, encoding) VALUES (%s, %s, %s)", (name, image, encoding))
    db_connection.commit()
    cursor.close()

def get_students_data():
    cursor = db_connection.cursor()
    cursor.execute("SELECT name, image, encoding FROM Students")
    students_data = cursor.fetchall()
    cursor.close()
    return students_data

def findEncodings(imagesList):
    encodeList = []
    for img in imagesList:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)[0]
        encodeList.append(encode)

    return encodeList

def upload_images_to_database():
    folderPath = 'Files/Images'
    pathList = os.listdir(folderPath)
    print(pathList)
    imgList = []
    studentIds = []
    for path in pathList:
        imgList.append(cv2.imread(os.path.join(folderPath, path)))
        studentIds.append(os.path.splitext(path)[0])

        image_encoded = cv2.imencode(".png", cv2.imread(os.path.join(folderPath, path)))[1].tobytes()
        encode = findEncodings([cv2.imread(os.path.join(folderPath, path))])[0]

        insert_student_data(os.path.splitext(path)[0], image_encoded, pickle.dumps(encode))

    print(studentIds)

def load_students_data():
    cursor = db_connection.cursor(dictionary=True)
    cursor.execute("SELECT name, encoding FROM Students")
    students_data = cursor.fetchall()
    cursor.close()
    return students_data

def main():
    create_table()
    upload_images_to_database()

    # Load students' data from the database
    students_data = load_students_data()

    # Extract known encodings and names from students' data
    encodeListKnown = [pickle.loads(student['encoding']) for student in students_data]
    studentIds = [student['name'] for student in students_data]
    encodeListKnownWithIds = [encodeListKnown, studentIds]

    # Save encodings to a file
    file = open("EncodeFile.p", 'wb')
    pickle.dump(encodeListKnownWithIds, file)
    file.close()
    print("File Saved")

if __name__ == "__main__":
    main()
