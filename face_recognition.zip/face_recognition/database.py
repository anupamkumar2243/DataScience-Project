import mysql.connector

# Set up your MySQL connection
db_connection = mysql.connector.connect(
    host="localhost",
    user="Roney",
    password="root",
    database="face_recognition"
)

def create_table():
    cursor = db_connection.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS students (id VARCHAR(255) PRIMARY KEY, name VARCHAR(255), major VARCHAR(255), starting_year INT, total_attendance INT, standing VARCHAR(1), year INT, last_attendance_time DATETIME)")
    db_connection.commit()
    cursor.close()

def insert_student_data(id, name, major, starting_year, total_attendance, standing, year, last_attendance_time):
    cursor = db_connection.cursor()
    cursor.execute("INSERT INTO students (id, name, major, starting_year, total_attendance, standing, year, last_attendance_time) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)", (id, name, major, starting_year, total_attendance, standing, year, last_attendance_time))
    db_connection.commit()
    cursor.close()

def upload_data_to_database(data):
    for key, value in data.items():
        insert_student_data(key, value['name'], value['major'], value['starting_year'], value['total_attendance'], value['standing'], value['year'], value['last_attendance_time'])

def main():
    data = {
        "852741":
            {
                "name": "Emly Blunt",
                "major": "Economics",
                "starting_year": 2021,
                "total_attendance": 12,
                "standing": "B",
                "year": 1,
                "last_attendance_time": "2022-12-11 00:54:34"
            },
        "963852":
            {
                "name": "Elon Musk",
                "major": "Physics",
                "starting_year": 2020,
                "total_attendance": 7,
                "standing": "G",
                "year": 2,
                "last_attendance_time": "2022-12-11 00:54:34"
            }
    }

    create_table()
    upload_data_to_database(data)

if __name__ == "__main__":
    main()
